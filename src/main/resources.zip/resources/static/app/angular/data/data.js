﻿'use strict';

/*
This module 
*/
angular.module('SampleApplication.Angular.Data', ['ngResource','angular-storage'])
	.controller('HomeController', ['$scope','$http','$location','store', function ($scope, $http,$location,store) {
                  console.log("Home Controller Start Here");
           var headerDetails = {headers: {'Content-Type': 'application/json'}};   
            $scope.loggedInAccount = store.get("account");
            store.set("loggedInAccount",$scope.loggedInAccount);
       console.log("--------------------");
        console.log("Logged In Account");
       console.log($scope.loggedInAccount);
            
      $http.get('/api/person/personId/'+ $scope.loggedInAccount.personId,headerDetails).then(function(res)
      {
        console.log("--------------------");
        console.log("Logged In Person");
        store.set("loggedInPerson",res.data);
        $scope.loggedInPerson = res.data;
        console.log($scope.loggedInPerson);
        console.log("--------------------");

      });
            $scope.getChowNow = function()
            {
               $scope.searchAddress = window.globals.address
                  console.log($scope.searchAddress);
               
               if($scope.searchAddress != null)
               {
                   store.set("searchAddress",$scope.searchAddress)
                   $location.path("/viewRestaurant");
               }
               
            }
            $scope.becomeDriver = function()
            {
                 $location.path("/driverReg");
            }
            $scope.becomePartner  = function()
            {
                  $location.path("/PartnerReg");
            } 
            $scope.logout  = function()
            {
                  console.log("Please logout safely");
            } 
        
                  console.log(window.globals.address); 
                  
                  
              
       }])
	.controller('RegisterController', ['$scope','$http' , function ($scope, $http) {
               
                        
                       
	  console.log($scope.email);
	 
	   
	   $scope.register = function()
	   {
		    var person = {

			"firstName" :  $scope.person.name,
			"lastName" :  $scope.person.surname,
			"email" :  $scope.person.email,
			"password" :  $scope.person.password,
			"mobileNumber" :  $scope.person.phone
                    }
			 console.log(person);
			 
			$http.post('api/userAccount/post', person).then(function(res)
			{
				if(res.data != null)
                                {
                                   $location.path("/signIn");
                                }
                                
			})
                          
	   }
         
     
    }])

.service('myservice', function(){

  this.setOwnerInfo = function(ownerInfo){
    this.ownerInfo = ownerInfo;
  };

  this.getOwnerInfo = function(){
    return this.ownerInfo;
  };
})

.controller('SignInController', ['$scope','$http','$location','store', function ($scope, $http,$location,store) {
    	
        var headerDetails = {headers: {'Content-Type': 'application/json'}};
	$scope.login = function()
	{
             var login = {
			"username" :  $scope.username,
			"password" :  $scope.pwd	
                        }
                $http.post('api/userAccount/session/login',login).then(function(res)
                {
                       //myservice.setOwnerInfo(res.data);
                       console.log(res.data);
                       store.set("account",res.data);
                     if(res.data.role == "Customer")
                     {
                          $location.path("/home");
                     }else if(res.data.role == "Admin")
                     {
                         $location.path("/AdminPortal");
                     }else if(res.data.role == "Partner")
                     {
                         $location.path("/PartnerPortal");
                     }
                                                   
                });	
	}
   
    }])	

.controller('driverRegController', ['$scope','$http','$location' , function ($scope, $http,$location) {

        $scope.options = ["1","2","3","4"];
        $scope.optionsTime = ["Anytime","Nights And Weekends","Weekends Only","Weekdays Only"];
        $scope.optionsPart = ["Full Time","Part TIme","Others"];
        $scope.transportOption = ["Car","Bike","Other Transport"];
        $scope.names = ['Yes', 'No'];
        $scope.driverRequest = { favorite: 'Yes' };
        
        $scope.submitDriverForm = function(driverRequest)
        {
            
       
          var driverReq = {
                  "avaliabilty": driverRequest.availability,
                  "emailAddress": driverRequest.emailAddress,
                  "fullName": driverRequest.fullName,
                  "jobTime": driverRequest.hours,
                  "licenece": $scope.driverRequest.favorite,
                  "location": driverRequest.location,
                  "phoneNumber": driverRequest.phoneNumber,
                  "transport": driverRequest.transport
                }
                
                console.log(driverRequest);
                $http.post('api/driverRequest/post',driverReq).then(function(res)
                {
                    console.log(res.data);
                                                   
                });
        }
     
    }])	

.controller('partnerRegController', ['$scope','$http','$location' , function ($scope, $http,$location) {
    
        $scope.submitPartnerForm = function(partnerRequest)
        {
         
         var partnerReq =  {
                "additionalInfo": partnerRequest.additionalInfo,
                "emailAddres": partnerRequest.emailAddress,
                "fullName": partnerRequest.fullName,
                "location": partnerRequest.location,
                "phoneNumber": partnerRequest.phoneNumber,
                "restuarantName": partnerRequest.restaurant
                }
               $http.post('api/partnerRequest/post',partnerReq).then(function(res)
                {
                   console.log(res.data.additionalInfo);
                                                   
                });
        }
    }])	
 .controller('AdminController', ['$scope','$http','$location' , function ($scope, $http,$location) {
     var headerDetails = {headers: {'Content-Type': 'application/json'}};
        console.log("AdminController");
        
         $http.get('/api/person/all',headerDetails ).then(function(res)
         {
                    console.log(res.data);
                    $scope.people = res.data;                               
        });
        $http.get('/api/userAccount/userAccounts/all',headerDetails ).then(function(res)
         {
                    console.log(res.data);
                    $scope.userAccounts = res.data;  
                                                   
        });
        $http.get('/api/driverRequest/all',headerDetails ).then(function(res)
        {
                    console.log(res.data);
                     $scope.driverRequests = res.data;                                 
        });
        
        $http.get('/api/partnerRequest/all',headerDetails ).then(function(res)
        {
                    console.log(res.data);
                     $scope.partnerRequests = res.data;   

                  
        });
        
        $scope.getPartnerRequest= function(partnerRequest)
        {
                var randomPassword = Math.floor(Math.random() * 99999999);
                console.log(partnerRequest);
                var splitFullName   = partnerRequest.fullName.split(" ");
                var firstName = splitFullName[0];
                var lastName = splitFullName[1];
             
            var partnerPerson = {
                        "email": partnerRequest.emailAddres,
                        "firstName": firstName,
                        "lastName": lastName ,
                        "mobileNumber": partnerRequest.phoneNumber,
                        "password": randomPassword
                   }
           
            console.log(partnerPerson);
            
        $http.post('/api/userAccount/partner/post',partnerPerson,headerDetails ).then(function(res)
        {
            
            console.log($scope.partnerAccount );               
        });
            
        }
            
  }])	
   .controller("PartnerController", ['$scope','$http','$location','store', function ($scope, $http,$location,store) { 
        console.log("Parter Controller Start Here");
        $scope.categories = [];
          var personId = store.get("account").personId;
          console.log(store.get("account"));
          var headerDetails = {headers: {'Content-Type': 'application/json'}};
           $http.get('/api/person/personId/'+ personId,headerDetails).then(function(res)
           {  
                 $scope.partnerInfo = res.data; 
                 console.log($scope.partnerInfo);

           });
 
     
        var imageCopy = null;
        var image = null;
        var handleImageSelect = function(evt) {
        var files = evt.target.files;
        var file = files[0];

            if (files && file) {
                var reader = new FileReader();
                    reader.onload = function(readerEvt) {
                        var binaryString = readerEvt.target.result;
                        imageCopy = btoa(binaryString);
                        image = 'data:image/octet-stream;base64,'+ imageCopy;       
                        console.log(image);
                    };

                 reader.readAsBinaryString(file);	
            }
        };

        if (window.File && window.FileReader && window.FileList && window.Blob) {
           document.getElementById('filePickerImage').addEventListener('change', handleImageSelect, false);
        } else {
           alert('The File APIs are not fully supported in this browser.');
       }
        
        $scope.addRestaurant = function()
        {
              var restaurant = {
                        "accountId": store.get("account").accountId,
                        "address": window.globals.address.formated_address,
                        "image": image,
                        "name": $scope.restaurantName
                        }
                        
                   console.log(restaurant)     
           $http.post('/api/restaurant/post',restaurant).then(function(res)
           {
                 store.set("restId",res.data.restaurantId);
           });
        }
         $http.get('/api/restaurant/get/'+ store.get("account").accountId ,headerDetails).then(function(res)
         {
             console.log(res.data);
             if(res.data.categoryId != null)
             {
                    for (var i = 0; i < res.data.categoryId.length; i++) {

                       if(res.data.categoryId[i] != null)
                       {
                          console.log(res.data.categoryId[i]);
                            $http.get('/api/restaurant/category/'+ res.data.categoryId[i],headerDetails).then(function(res)
                            {   
                                $scope.categories.push(res.data);

                            });
 
                       }
                   }

             } 

         });
         
            console.log($scope.lists);
        $scope.addCategory = function()
        {
           console.log("Enter Category Name " + $scope.categoryName +  "for restaurnat Id" + $scope.restId); 
                          
                    $http.get('/api/restaurant/get/'+ store.get("account").accountId ,headerDetails).then(function(res)
                    {
                         var category = {
                        "name": $scope.categoryName,
                        "restaurantId":   res.data.restaurantId
                            }
                            store.set("restId",res.data.restaurantId);
                        $http.post('/api/restaurant/menu/category',category).then(function(res)
                        {
                         //console.log(res.data);
                            $http.post('/api/restaurant/addCategories/'+ store.get("account").accountId,res.data).then(function(res)
                           {
                         
                           
                           });
                        });
                     });
        }

         $scope.addItem= function()
        {
           console.log("Enter Item Info" + $scope.category.categoryId); 
           var item = {
                "categoryId" : $scope.category.categoryId,
                "name": $scope.itemName,
                "price": $scope.itemDescription,
                "shortDescription": $scope.itemPrice}
             /*
            $http.post('/api/restaurant/category/item',item).then(function(res)
            {
                console.log(res.data);
            });*/
             
             //GET /api/restaurant/category/item/{categoryId}
            $http.post('/api/restaurant/category/item',item).then(function(res)
            {
                console.log(res.data);
                 $http.post('/api/restaurant/addItems/'+ $scope.category.categoryId,res.data).then(function(res)
                {
                    console.log(res.data);
                });
                
            });
        }
        
        
        
         
   }])
     .controller("UpdateProfileController", ['$scope','$http','$location','store', function ($scope, $http,$location,store) { 
        console.log("Update ProfileController Start Here");
        
        var headerDetails = {headers: {'Content-Type': 'application/json'}};
        $scope.personInfo = store.get("loggedInPerson");
        console.log($scope.personInfo);
        $scope.names = ['Male', 'Female'];
        $scope.gender = { favorite: 'Yes' };
        
        $scope.profileFirstName = $scope.personInfo.firstName;
         $scope.profileLastName = $scope.personInfo.lastName;
          $scope.profilePhoneNumber = $scope.personInfo.mobileNumber;
          
          
          $scope.edit = function()
          {
              console.log("edit");
             
                        var editProfile = {
                                    "alternateNumber": $scope.profileAlternateNumber,
                                    "firstName": $scope.profileFirstName,
                                    "gender": $scope.gender.favorite,
                                    "id": $scope.personInfo.id,
                                    "lastName": $scope.profileLastName,
                                    "mobileNumber": $scope.profilePhoneNumber
                                }
                                
               console.log(editProfile);
               //POST /
                $http.post('api/person/edit',editProfile).then(function(res)
                {
                    if(res.data != null)
                    {
                        store.set("editedProfile",res.data); 
                    }
                                  
                });
          }
      
   }])
        .controller("UpdateEmailAndPasswordController", ['$scope','$http','$location','store', function ($scope, $http,$location,store) { 
        console.log("Update Email And Password Controller Start Here");
        
             $scope.accountInfo = store.get("loggedInAccount");
            console.log($scope.accountInfo);
            $scope.updateEmail = $scope.accountInfo.username;
            $scope.updatePassword = $scope.accountInfo.password;
            $scope.updateEmailAndPassword = function()
            {
                var updateAccount = {
                                        "accountId": $scope.accountInfo.accountId,
                                        "password": $scope.accountInfo.password,
                                        "personId":  $scope.accountInfo.personId,
                                        "username": $scope.updateEmail 
                                    }
                                    
                                    
                 console.log(updateAccount);
                //POST /api/userAccount/update
                $http.post('api/userAccount/update',updateAccount).then(function(res)
                {
                    if(res.data != null)
                    {
                        store.set("updateAccount",res.data); 
                    }
                                  
                });
            }
   }])
         .controller("forgotPasswordController", ['$scope','$http','$location','store', function ($scope, $http,$location,store) { 
        console.log("OrderHistory Controller Start Here");
        
            $scope.sendEmail = function()
            {
                console.log("Send Email to " + $scope.userEmail);
            }
   }])

          .controller("sendforgotEmailController", ['$scope','$http','$location','store', function ($scope, $http,$location,store) { 
        console.log("OrderHistory Controller Start Here");
        
      
   }])
       .controller("orderHistoryController", ['$scope','$http','$location','store', function ($scope, $http,$location,store) { 
        console.log("OrderHistory Controller Start Here");
        
      
   }])
    .controller("FAQsController", ['$scope','$http','$location','store', function ($scope, $http,$location,store) { 
        console.log("FAQs Controller Start Here");
        
      
        
   }])
   .controller("termsAndConditionsController", ['$scope','$http','$location','store', function ($scope, $http,$location,store) { 
        console.log("Terms And Conditions Controller Controller Start Here");
        
      
         
   }])
      .controller("viewRestaurantController", ['$scope','$http','$location','store', function ($scope, $http,$location,store) { 
        console.log("view Restaurants");
        
          $scope.customerAddress =  store.get("searchAddress")
          var address = $scope.customerAddress.formated_address.split(",");
          console.log(address);
          $scope.streetName = address[0];
          $scope.city = address[2];
          console.log($scope.streetName  +  " "  + $scope.city);
          $scope.changeAddress = function()
          {
              $location.path("/home");
          }
          
          
          $http.get('/api/restaurant/all').then(function(res)
           {
               console.log(res.data);
                                  
           });
             
   }])
   
   

    

